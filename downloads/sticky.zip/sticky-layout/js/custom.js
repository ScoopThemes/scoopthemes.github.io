var appMaster = {
	aFunction: function(){
		// Add you custom here and don't forget to change the object title (anotherFunction)
	    
	},
	anotherFunction: function(){
		// Add you custom here and don't forget to change the object title (anotherFunction)
	}
}